CREATE VIEW CompleteInfo as
SELECT S.studentID, S.firstName, S.lastName, C.courseID, C.name, G.grade
From grades as G
         INNER JOIN students S on G.studentID = S.studentID
         INNER JOIN courses as C on G.courseID = C.courseID;

